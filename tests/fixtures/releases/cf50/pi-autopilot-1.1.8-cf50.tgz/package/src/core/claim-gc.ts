import { existsSync } from 'node:fs';
import { mkdir } from 'node:fs/promises';
import { join } from 'node:path';

import { proveLegacyReadAttemptTerminal } from './coordination/legacy-read-terminal.ts';
import { appendClaimEvent, coordinationRootForRepo, readActiveAutopilots, readPathClaims, readUnitIndex, resolveAutopilotStateRoot, resolveRepoIdentity, taskRootForActiveAutopilot, withAutopilotFileLock, writeJsonAtomic, writePathClaims, type ActiveAutopilotRow, type AutopilotPathClaim, type ProcessEnvLike } from './parallel-runtime.ts';
import { coordinationCutoverCommitted } from './coordination/migration-paths.ts';
import { runLegacyCoordinationPreflight } from './coordination/legacy-preflight.ts';

export interface AutopilotClaimGcCandidate {
  readonly claim: AutopilotPathClaim;
  readonly stale: boolean;
  readonly proof: readonly string[];
  readonly blockers: readonly string[];
}

export interface AutopilotClaimGcResult {
  readonly schema_version: 'autopilot.claim_gc.v1';
  readonly mode: 'dry-run' | 'apply';
  readonly repo_key: string;
  readonly released_claims: readonly string[];
  readonly candidates: readonly AutopilotClaimGcCandidate[];
  readonly evidence_path: string | null;
  readonly created_at: string;
}

export class AutopilotClaimGcError extends Error {
  override readonly name = 'AutopilotClaimGcError';
  readonly code: string;

  constructor(code: string, message: string) {
    super(`AutopilotClaimGcError [${code}]: ${message}`);
    this.code = code;
  }
}

interface ClaimGcEvaluation {
  readonly candidates: readonly AutopilotClaimGcCandidate[];
  readonly releasedLabels: readonly string[];
}

interface RuntimeTerminalProof {
  readonly stale: boolean;
  readonly proof: readonly string[];
  readonly blockers: readonly string[];
}

function fail(code: string, message: string): never {
  throw new AutopilotClaimGcError(code, message);
}

export async function runAutopilotClaimGc(input: {
  readonly sourceCwd: string;
  readonly apply: boolean;
  readonly env?: ProcessEnvLike;
  readonly now?: Date;
}): Promise<AutopilotClaimGcResult> {
  const env = input.env ?? process.env;
  const now = input.now ?? new Date();
  const repo = resolveRepoIdentity(input.sourceCwd);
  const coordinationRoot = coordinationRootForRepo(repo.repoKey, env);
  if (coordinationCutoverCommitted(resolveAutopilotStateRoot(env), repo.repoKey)) fail('legacy-authority-archived', 'claim GC is disabled after coordination cutover; coordinator reconciliation is authoritative.');
  if (!input.apply) {
    await withAutopilotFileLock(join(coordinationRoot, '.locks', 'activation.lock'), `claim-gc-preflight-active:${repo.repoKey}`, async () => {
      await withAutopilotFileLock(join(coordinationRoot, '.locks', 'path-claims.lock'), `claim-gc-preflight-claims:${repo.repoKey}`, async () => {
        await runLegacyCoordinationPreflight({
          coordinationRoot,
          repoKey: repo.repoKey,
          mode: 'claim-gc-dry-run',
          now,
        });
      });
    });
  }
  const rows = await readActiveAutopilots(coordinationRoot);
  const evaluate = async (): Promise<ClaimGcEvaluation> => {
    const claims = await readPathClaims(coordinationRoot);
    const candidates = await classifyClaimGcCandidates(rows, claims);
    const releasable = candidates.filter((candidate) => candidate.stale && candidate.blockers.length === 0).map((candidate) => candidate.claim);
    const releasedLabels: string[] = [];
    if (input.apply && releasable.length > 0) {
      const releaseKeys = new Set(releasable.map(claimKey));
      const remaining = claims.filter((claim) => !releaseKeys.has(claimKey(claim)));
      await writePathClaims(coordinationRoot, remaining);
      for (const claim of releasable) {
        releasedLabels.push(`${claim.claim_type} ${claim.path} ${claim.unit_id} attempt ${String(claim.attempt)}`);
        await appendClaimEvent(coordinationRoot, {
          schema_version: 'autopilot.claim_event.v1',
          event: 'release',
          ts: now.toISOString(),
          repo_key: repo.repoKey,
          autopilot_id: claim.autopilot_id,
          workstream: claim.workstream,
          workstream_run: claim.workstream_run,
          unit_id: claim.unit_id,
          attempt: claim.attempt,
          path: claim.path,
          claim_type: claim.claim_type,
          active_run_epoch: claim.active_run_epoch,
          reason: 'autopilot claim gc mechanical stale release',
        });
      }
    }
    if (input.apply && candidates.some((candidate) => candidate.blockers.length > 0 && candidate.stale)) {
      fail('incomplete-stale-proof', 'internal stale proof invariant failed.');
    }
    return { candidates, releasedLabels };
  };
  const evaluation = input.apply
    ? await withAutopilotFileLock(join(coordinationRoot, '.locks', 'path-claims.lock'), `claim-gc:${repo.repoKey}`, evaluate)
    : await evaluate();
  const resultWithoutPath: AutopilotClaimGcResult = {
    schema_version: 'autopilot.claim_gc.v1',
    mode: input.apply ? 'apply' : 'dry-run',
    repo_key: repo.repoKey,
    released_claims: [...evaluation.releasedLabels],
    candidates: [...evaluation.candidates],
    evidence_path: null,
    created_at: now.toISOString(),
  };
  const evidenceRoot = join(coordinationRoot, 'claim-gc');
  await mkdir(evidenceRoot, { recursive: true });
  const evidencePath = join(evidenceRoot, `${timestamp(now)}.${input.apply ? 'apply' : 'dry-run'}.json`);
  const result = { ...resultWithoutPath, evidence_path: evidencePath };
  await writeJsonAtomic(evidencePath, result);
  return result;
}

async function classifyClaimGcCandidates(
  rows: readonly ActiveAutopilotRow[],
  claims: readonly AutopilotPathClaim[],
): Promise<readonly AutopilotClaimGcCandidate[]> {
  const candidates: AutopilotClaimGcCandidate[] = [];
  const fallbackProofs = new Map<string, RuntimeTerminalProof>();
  for (const claim of claims) {
    const row = rows.find((active) => active.autopilot_id === claim.autopilot_id && active.workstream_run === claim.workstream_run);
    if (row === undefined) {
      candidates.push({ claim, stale: false, proof: [], blockers: ['active Autopilot row missing; refuse to infer stale without archive evidence'] });
      continue;
    }
    if (row.status === 'closed' || row.status === 'crashed') {
      candidates.push({ claim, stale: true, proof: [`active row status is ${row.status}`], blockers: [] });
      continue;
    }
    const taskRoot = taskRootForActiveAutopilot(row);
    if (!existsSync(taskRoot)) {
      candidates.push({ claim, stale: false, proof: [], blockers: [`task root missing while active row is ${row.status}`] });
      continue;
    }
    const index = await readUnitIndex(taskRoot);
    const unit = index.units.find((candidate) => candidate.unit_id === claim.unit_id && candidate.attempt === claim.attempt);
    if (unit !== undefined) {
      if (unit.status === 'merged' || unit.status === 'aborted' || unit.status === 'quarantined' || unit.status === 'superseded') {
        candidates.push({ claim, stale: true, proof: [`unit attempt status is ${unit.status}`, `archive_ref=${unit.archive_ref ?? 'none'}`], blockers: [] });
        continue;
      }
      candidates.push({ claim, stale: false, proof: [], blockers: [`unit attempt status is live: ${unit.status}`] });
      continue;
    }
    if (claim.claim_type !== 'READ') {
      candidates.push({ claim, stale: false, proof: [], blockers: ['unit attempt metadata missing; runtime terminal fallback applies only to READ claims'] });
      continue;
    }
    const fallbackKey = `${row.autopilot_id}\0${row.workstream_run}\0${claim.workstream}\0${claim.unit_id}\0${String(claim.attempt)}`;
    let fallback = fallbackProofs.get(fallbackKey);
    if (fallback === undefined) {
      fallback = await proveRuntimeTerminalReadClaim(row, claim);
      fallbackProofs.set(fallbackKey, fallback);
    }
    candidates.push({ claim, stale: fallback.stale, proof: fallback.proof, blockers: fallback.blockers });
  }
  return Object.freeze(candidates);
}

async function proveRuntimeTerminalReadClaim(
  row: ActiveAutopilotRow,
  claim: AutopilotPathClaim,
): Promise<RuntimeTerminalProof> {
  const result = proveLegacyReadAttemptTerminal({ runtimeRoot: row.runtime_root, workstream: row.workstream, unitId: claim.unit_id, attempt: claim.attempt });
  if (!result.proven) return { stale: false, proof: [], blockers: [result.reason] };
  return {
    stale: true,
    proof: ['unit attempt metadata missing; using validated runtime terminal proof', ...result.proof.mechanicalProof],
    blockers: [],
  };
}

function claimKey(claim: AutopilotPathClaim): string {
  return `${claim.autopilot_id}\0${claim.workstream_run}\0${claim.unit_id}\0${String(claim.attempt)}\0${claim.claim_type}\0${claim.path}`;
}

function timestamp(now: Date): string {
  return now.toISOString().replace(/[-:.]/gu, '').replace(/Z$/u, 'Z');
}

function errorMessage(error: unknown): string {
  return error instanceof Error ? error.message : String(error);
}
