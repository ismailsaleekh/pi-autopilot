import {
  AUTOPILOT_AUDIT_CLASSIFICATION_VALUES,
  AUTOPILOT_CLOSURE_GATE_STATUS_VALUES,
  AUTOPILOT_COMMAND_STATUS_VALUES,
  AUTOPILOT_CONTEXT_GATE_VALUES,
  AUTOPILOT_DECISION_EVENT_VALUES,
  AUTOPILOT_EVENT_TYPE_VALUES,
  AUTOPILOT_EXCEPTION_STATE_VALUES,
  AUTOPILOT_EXECUTION_AUDIT_PATH_SET_VALUES,
  AUTOPILOT_EXECUTION_COMMIT_ORIGIN_VALUES,
  AUTOPILOT_HANDOFF_REASON_VALUES,
  AUTOPILOT_HEAD_CHANGE_KIND_VALUES,
  AUTOPILOT_QUALITY_PROFILE_VALUES,
  AUTOPILOT_RISK_LEVEL_VALUES,
  AUTOPILOT_ROLE_VALUES,
  AUTOPILOT_SEVERITY_VALUES,
  AUTOPILOT_STATUS_CHANGED_PATHS_LIMIT,
  AUTOPILOT_TEMPLATE_VALUES,
  AUTOPILOT_THINKING_VALUES,
  AUTOPILOT_UNIT_STATE_VALUES,
  AUTOPILOT_VERDICT_VALUES,
  AUTOPILOT_WORK_ITEM_STATE_VALUES,
  AUTOPILOT_WORKSTREAM_STATUS_VALUES,
} from './types.ts';
import { opaqueToolCallIdJsonSchema } from '../tool-call-id.ts';

export type JsonMap = Readonly<Record<string, unknown>>;

export const AUTOPILOT_SCHEMA_ID_BASE = 'urn:pi-autopilot:schemas' as const;

const ISO_TIMESTAMP_PATTERN = '^\\d{4}-\\d{2}-\\d{2}T\\d{2}:\\d{2}:\\d{2}\\.\\d{3}Z$';
const SHA256_PATTERN = '^sha256:[a-f0-9]{64}$';
const WORKSTREAM_PATTERN = '^[A-Za-z0-9][A-Za-z0-9._-]{0,127}$';
const UNIT_ID_PATTERN = '^[A-Za-z0-9][A-Za-z0-9._:-]{0,127}$';
const NOT_CHAR = '!';
const NEGATIVE_LOOKAHEAD = `(?${NOT_CHAR}`;
const RELATIVE_PATH_PATTERN =
  `^${NEGATIVE_LOOKAHEAD}/)${NEGATIVE_LOOKAHEAD}[A-Za-z]:)${NEGATIVE_LOOKAHEAD}.*(?:^|/)\\.\\.(?:/|$))` +
  `${NEGATIVE_LOOKAHEAD}.*(?:^|/)\\.(?:/|$))${NEGATIVE_LOOKAHEAD}.*\\u0000)${NEGATIVE_LOOKAHEAD}.*\\\\)` +
  '[^\\s][^\\u0000\\\\]{0,511}$';
const ABSOLUTE_PATH_PATTERN =
  `^${NEGATIVE_LOOKAHEAD}.*(?:^|/)\\.\\.(?:/|$))${NEGATIVE_LOOKAHEAD}.*(?:^|/)\\.(?:/|$))` +
  `${NEGATIVE_LOOKAHEAD}.*\\u0000)/(?:[^\\u0000/]+/?)*$`;
const MODEL_PATTERN = `^${NEGATIVE_LOOKAHEAD}openrouter/)${NEGATIVE_LOOKAHEAD}.*\\s)[A-Za-z0-9._/-]{3,120}$`;

const boundedString = (maxLength: number, minLength = 1): JsonMap => ({
  type: 'string',
  minLength,
  maxLength,
});

const enumSchema = (values: readonly string[]): JsonMap => ({
  type: 'string',
  enum: [...values],
});

const relativePathSchema = (): JsonMap => ({
  type: 'string',
  minLength: 1,
  maxLength: 512,
  pattern: RELATIVE_PATH_PATTERN,
});

const absolutePathSchema = (): JsonMap => ({
  type: 'string',
  minLength: 1,
  maxLength: 1024,
  pattern: ABSOLUTE_PATH_PATTERN,
});

const isoTimestampSchema = (): JsonMap => ({
  type: 'string',
  pattern: ISO_TIMESTAMP_PATTERN,
});

const sha256Schema = (): JsonMap => ({
  type: 'string',
  pattern: SHA256_PATTERN,
});

const unitIdSchema = (): JsonMap => ({
  type: 'string',
  minLength: 1,
  maxLength: 128,
  pattern: UNIT_ID_PATTERN,
});

const workstreamSchema = (): JsonMap => ({
  type: 'string',
  minLength: 1,
  maxLength: 128,
  pattern: WORKSTREAM_PATTERN,
});

const boundedArray = (items: JsonMap, maxItems: number, minItems = 0): JsonMap => ({
  type: 'array',
  minItems,
  maxItems,
  items,
});

const noExtraMap = (properties: Record<string, JsonMap>, required: readonly string[]): JsonMap => ({
  type: 'object',
  additionalProperties: false,
  properties,
  required: [...required],
});

const integerCountSchema = (): JsonMap => ({
  type: 'integer',
  minimum: 0,
  maximum: 1_000_000_000,
});

const executionAuditPathCountProperties = Object.fromEntries(
  AUTOPILOT_EXECUTION_AUDIT_PATH_SET_VALUES.map((pathSet) => [pathSet, integerCountSchema()]),
) as Record<(typeof AUTOPILOT_EXECUTION_AUDIT_PATH_SET_VALUES)[number], JsonMap>;

export const AUTOPILOT_EXECUTION_AUDIT_PATH_COUNTS_JSON_SCHEMA = noExtraMap(
  executionAuditPathCountProperties,
  AUTOPILOT_EXECUTION_AUDIT_PATH_SET_VALUES,
);

export const AUTOPILOT_CONTEXT_REF_JSON_SCHEMA = noExtraMap(
  {
    path: relativePathSchema(),
    purpose: boundedString(240),
    sha256: sha256Schema(),
    byte_count: { type: 'integer', minimum: 0, maximum: 1_000_000_000 },
  },
  ['path', 'purpose'],
);

export const AUTOPILOT_EVIDENCE_REF_JSON_SCHEMA = noExtraMap(
  {
    path: relativePathSchema(),
    sha256: sha256Schema(),
    byte_count: { type: 'integer', minimum: 0, maximum: 1_000_000_000 },
    description: boundedString(240),
  },
  ['path'],
);

export const AUTOPILOT_COMMAND_SUMMARY_JSON_SCHEMA = noExtraMap(
  {
    command: boundedString(800),
    status: enumSchema(AUTOPILOT_COMMAND_STATUS_VALUES),
    exit_code: { anyOf: [{ type: 'integer', minimum: -1, maximum: 255 }, { type: 'null' }] },
    summary: boundedString(360),
    evidence_ref: relativePathSchema(),
  },
  ['command', 'status', 'exit_code', 'summary'],
);

export const AUTOPILOT_WITNESS_SPEC_JSON_SCHEMA = noExtraMap(
  {
    id: {
      type: 'string',
      minLength: 1,
      maxLength: 96,
      pattern: '^[A-Za-z0-9][A-Za-z0-9._:-]{0,95}$',
    },
    expected_signal: boundedString(500),
    required: { type: 'boolean' },
    command: boundedString(800),
    inspection_target: boundedString(500),
    blocker_reason: boundedString(500),
  },
  ['id', 'expected_signal', 'required'],
);

export const AUTOPILOT_VERIFICATION_PLAN_JSON_SCHEMA = noExtraMap(
  {
    positive_witnesses: boundedArray(AUTOPILOT_WITNESS_SPEC_JSON_SCHEMA, 80),
    negative_witnesses: boundedArray(AUTOPILOT_WITNESS_SPEC_JSON_SCHEMA, 80),
    regression_witnesses: boundedArray(AUTOPILOT_WITNESS_SPEC_JSON_SCHEMA, 80),
    real_boundary_witnesses: boundedArray(AUTOPILOT_WITNESS_SPEC_JSON_SCHEMA, 80),
    blast_radius_checks: boundedArray(AUTOPILOT_WITNESS_SPEC_JSON_SCHEMA, 80),
    docs_schema_prompt_checks: boundedArray(AUTOPILOT_WITNESS_SPEC_JSON_SCHEMA, 80),
    dirty_tree_checks: boundedArray(AUTOPILOT_WITNESS_SPEC_JSON_SCHEMA, 80),
  },
  [
    'positive_witnesses',
    'negative_witnesses',
    'regression_witnesses',
    'real_boundary_witnesses',
    'blast_radius_checks',
    'docs_schema_prompt_checks',
    'dirty_tree_checks',
  ],
);

export const AUTOPILOT_UPSTREAM_REF_JSON_SCHEMA = noExtraMap(
  {
    unit_id: unitIdSchema(),
    purpose: boundedString(360),
    status_ref: relativePathSchema(),
    audit_ref: relativePathSchema(),
  },
  ['unit_id', 'purpose'],
);

export const AUTOPILOT_FINDING_JSON_SCHEMA = noExtraMap(
  {
    id: {
      type: 'string',
      minLength: 1,
      maxLength: 96,
      pattern: '^[A-Za-z0-9][A-Za-z0-9._:-]{0,95}$',
    },
    severity: enumSchema(['minor-local', 'major-local', 'critical']),
    path: relativePathSchema(),
    summary: boundedString(500),
    evidence_refs: boundedArray(AUTOPILOT_EVIDENCE_REF_JSON_SCHEMA, 12),
  },
  ['id', 'severity', 'summary'],
);

export const AUTOPILOT_UNIT_SPEC_JSON_SCHEMA = {
  $id: `${AUTOPILOT_SCHEMA_ID_BASE}/unit-spec.v1.json`,
  type: 'object',
  additionalProperties: false,
  properties: {
    schema_version: { const: 'autopilot.unit_spec.v1' },
    workstream: workstreamSchema(),
    unit_id: unitIdSchema(),
    role: enumSchema(AUTOPILOT_ROLE_VALUES),
    template: enumSchema(AUTOPILOT_TEMPLATE_VALUES),
    attempt: { type: 'integer', minimum: 1, maximum: 999 },
    objective: boundedString(1200),
    cwd: absolutePathSchema(),
    model: { type: 'string', minLength: 3, maxLength: 120, pattern: MODEL_PATTERN },
    thinking: enumSchema(AUTOPILOT_THINKING_VALUES),
    owned_paths: boundedArray(relativePathSchema(), 120),
    read_only_paths: boundedArray(relativePathSchema(), 200),
    untouchable_paths: boundedArray(relativePathSchema(), 200),
    context_refs: boundedArray(AUTOPILOT_CONTEXT_REF_JSON_SCHEMA, 80),
    validation_commands: boundedArray(boundedString(800), 40),
    status_output: absolutePathSchema(),
    receipt_output: absolutePathSchema(),
    evidence_dir: absolutePathSchema(),
    stop_boundary: boundedString(1200),
    quality_profile: enumSchema(AUTOPILOT_QUALITY_PROFILE_VALUES),
    risk_level: enumSchema(AUTOPILOT_RISK_LEVEL_VALUES),
    acceptance_criteria: boundedArray(boundedString(500), 80),
    verification_plan: AUTOPILOT_VERIFICATION_PLAN_JSON_SCHEMA,
    closure_criteria: boundedArray(boundedString(500), 80),
    upstream_refs: boundedArray(AUTOPILOT_UPSTREAM_REF_JSON_SCHEMA, 80),
    timeout_seconds: { type: 'integer', minimum: 60, maximum: 86_400 },
    render_prompt_snapshot: { type: 'boolean' },
  },
  required: [
    'schema_version',
    'workstream',
    'unit_id',
    'role',
    'template',
    'attempt',
    'objective',
    'cwd',
    'model',
    'thinking',
    'owned_paths',
    'read_only_paths',
    'untouchable_paths',
    'context_refs',
    'validation_commands',
    'status_output',
    'receipt_output',
    'evidence_dir',
    'stop_boundary',
  ],
  allOf: [
    {
      if: { properties: { role: { enum: ['implement', 'fix'] } }, required: ['role'] },
      then: { properties: { owned_paths: { type: 'array', minItems: 1 } } },
    },
    {
      if: { properties: { role: { enum: ['validate', 'bughunt'] } }, required: ['role'] },
      then: { properties: { validation_commands: { type: 'array', minItems: 1 } } },
    },
  ],
} as const satisfies JsonMap;

export const AUTOPILOT_STATUS_ENTRY_JSON_SCHEMA = {
  $id: `${AUTOPILOT_SCHEMA_ID_BASE}/status-entry.v1.json`,
  type: 'object',
  additionalProperties: false,
  properties: {
    schema_version: { const: 'autopilot.status.v1' },
    workstream: workstreamSchema(),
    unit_id: unitIdSchema(),
    role: enumSchema(AUTOPILOT_ROLE_VALUES),
    attempt: { type: 'integer', minimum: 1, maximum: 999 },
    verdict: enumSchema(AUTOPILOT_VERDICT_VALUES),
    severity: enumSchema(AUTOPILOT_SEVERITY_VALUES),
    summary: boundedString(360),
    changed_paths: boundedArray(relativePathSchema(), AUTOPILOT_STATUS_CHANGED_PATHS_LIMIT),
    findings: boundedArray(AUTOPILOT_FINDING_JSON_SCHEMA, 80),
    commands: boundedArray(AUTOPILOT_COMMAND_SUMMARY_JSON_SCHEMA, 80),
    evidence_refs: boundedArray(AUTOPILOT_EVIDENCE_REF_JSON_SCHEMA, 80),
    report_ref: { anyOf: [AUTOPILOT_EVIDENCE_REF_JSON_SCHEMA, { type: 'null' }] },
    covered_witness_ids: boundedArray(
      {
        type: 'string',
        minLength: 1,
        maxLength: 96,
        pattern: '^[A-Za-z0-9][A-Za-z0-9._:-]{0,95}$',
      },
      200,
    ),
    next_action: boundedString(360),
  },
  required: [
    'schema_version',
    'workstream',
    'unit_id',
    'role',
    'attempt',
    'verdict',
    'severity',
    'summary',
    'changed_paths',
    'findings',
    'commands',
    'evidence_refs',
    'report_ref',
    'next_action',
  ],
  allOf: [
    {
      if: {
        properties: { role: { enum: ['strategy', 'implement', 'fix', 'adjudicate', 'extract'] } },
        required: ['role'],
      },
      then: { properties: { verdict: { enum: ['DONE', 'BLOCKED'] } } },
    },
    {
      if: { properties: { role: { enum: ['validate', 'bughunt'] } }, required: ['role'] },
      then: { properties: { verdict: { enum: ['PASS', 'NEEDS_FIX', 'BLOCKED'] } } },
    },
    {
      if: { properties: { verdict: { enum: ['PASS', 'DONE'] } }, required: ['verdict'] },
      then: {
        properties: { severity: { const: 'clean' }, findings: { type: 'array', maxItems: 0 } },
      },
    },
    {
      if: { properties: { verdict: { enum: ['NEEDS_FIX', 'BLOCKED'] } }, required: ['verdict'] },
      then: { properties: { severity: { enum: ['minor-local', 'major-local', 'critical'] } } },
    },
    {
      if: {
        properties: {
          role: { enum: ['strategy', 'validate', 'adjudicate', 'bughunt', 'extract'] },
        },
        required: ['role'],
      },
      then: { properties: { changed_paths: { type: 'array', maxItems: 0 } } },
    },
  ],
} as const satisfies JsonMap;

export const AUTOPILOT_EVENT_ROW_JSON_SCHEMA = {
  $id: `${AUTOPILOT_SCHEMA_ID_BASE}/event-row.v1.json`,
  type: 'object',
  additionalProperties: false,
  properties: {
    schema_version: { const: 'autopilot.event.v1' },
    id: { type: 'integer', minimum: 1, maximum: 9_000_000_000_000_000 },
    ts: isoTimestampSchema(),
    event: enumSchema(AUTOPILOT_EVENT_TYPE_VALUES),
    workstream: workstreamSchema(),
    unit_id: unitIdSchema(),
    role: enumSchema(AUTOPILOT_ROLE_VALUES),
    verdict: enumSchema(AUTOPILOT_VERDICT_VALUES),
    severity: enumSchema(AUTOPILOT_SEVERITY_VALUES),
    spec_ref: relativePathSchema(),
    status_ref: relativePathSchema(),
    receipt_ref: relativePathSchema(),
    evidence_ref: relativePathSchema(),
    summary: boundedString(360),
  },
  required: ['schema_version', 'id', 'ts', 'event', 'workstream', 'summary'],
  allOf: [
    {
      if: { properties: { event: { const: 'unit_spec_created' } }, required: ['event'] },
      then: {
        properties: {
          unit_id: unitIdSchema(),
          role: enumSchema(AUTOPILOT_ROLE_VALUES),
          spec_ref: relativePathSchema(),
        },
        required: ['unit_id', 'role', 'spec_ref'],
      },
    },
    {
      if: { properties: { event: { const: 'agent_completed' } }, required: ['event'] },
      then: {
        properties: {
          unit_id: unitIdSchema(),
          role: enumSchema(AUTOPILOT_ROLE_VALUES),
          verdict: enumSchema(AUTOPILOT_VERDICT_VALUES),
          status_ref: relativePathSchema(),
        },
        required: ['unit_id', 'role', 'verdict', 'status_ref'],
      },
    },
    {
      if: { properties: { event: { const: 'handoff_written' } }, required: ['event'] },
      then: { properties: { evidence_ref: relativePathSchema() }, required: ['evidence_ref'] },
    },
  ],
} as const satisfies JsonMap;

const stateUnitSchema = noExtraMap(
  {
    unit_id: unitIdSchema(),
    role: enumSchema(AUTOPILOT_ROLE_VALUES),
    state: enumSchema(AUTOPILOT_UNIT_STATE_VALUES),
    attempt: { type: 'integer', minimum: 1, maximum: 999 },
    spec_ref: relativePathSchema(),
    status_ref: relativePathSchema(),
    receipt_ref: relativePathSchema(),
    summary: boundedString(360),
  },
  ['unit_id', 'role', 'state', 'attempt', 'summary'],
);

const workItemSchema = noExtraMap(
  {
    work_item_id: unitIdSchema(),
    state: enumSchema(AUTOPILOT_WORK_ITEM_STATE_VALUES),
    source_changing: { type: 'boolean' },
    unit_ids: boundedArray(unitIdSchema(), 500),
    implementation_unit_id: unitIdSchema(),
    validation_unit_id: unitIdSchema(),
    audit_ref: relativePathSchema(),
    status_ref: relativePathSchema(),
    validation_status_ref: relativePathSchema(),
    summary: boundedString(360),
  },
  ['work_item_id', 'state', 'source_changing', 'unit_ids', 'summary'],
);

const scopeExceptionSchema = noExtraMap(
  {
    exception_id: unitIdSchema(),
    unit_id: unitIdSchema(),
    audit_ref: relativePathSchema(),
    paths: boundedArray(relativePathSchema(), 500, 1),
    state: enumSchema(AUTOPILOT_EXCEPTION_STATE_VALUES),
    decision_ref: relativePathSchema(),
    summary: boundedString(500),
  },
  ['exception_id', 'unit_id', 'audit_ref', 'paths', 'state', 'summary'],
);

const protectedPathExceptionSchema = noExtraMap(
  {
    exception_id: unitIdSchema(),
    unit_id: unitIdSchema(),
    audit_ref: relativePathSchema(),
    read_only_paths: boundedArray(relativePathSchema(), 500),
    untouchable_paths: boundedArray(relativePathSchema(), 500),
    state: enumSchema(AUTOPILOT_EXCEPTION_STATE_VALUES),
    decision_ref: relativePathSchema(),
    summary: boundedString(500),
  },
  ['exception_id', 'unit_id', 'audit_ref', 'read_only_paths', 'untouchable_paths', 'state', 'summary'],
);

const closureGateSchema = noExtraMap(
  {
    status: enumSchema(AUTOPILOT_CLOSURE_GATE_STATUS_VALUES),
    checked_at: isoTimestampSchema(),
    blocking_reasons: boundedArray(boundedString(500), 200),
    bughunt_status_ref: relativePathSchema(),
    decision_ref: relativePathSchema(),
    summary: boundedString(500),
  },
  ['status', 'blocking_reasons', 'summary'],
);

export const AUTOPILOT_STATE_JSON_SCHEMA = {
  $id: `${AUTOPILOT_SCHEMA_ID_BASE}/state.v1.json`,
  type: 'object',
  additionalProperties: false,
  properties: {
    schema_version: { const: 'autopilot.state.v1' },
    workstream: workstreamSchema(),
    updated_at: isoTimestampSchema(),
    status: enumSchema(AUTOPILOT_WORKSTREAM_STATUS_VALUES),
    context_gate: noExtraMap(
      {
        gate: enumSchema(AUTOPILOT_CONTEXT_GATE_VALUES),
        percent: { anyOf: [{ type: 'number', minimum: 0, maximum: 100 }, { type: 'null' }] },
      },
      ['gate', 'percent'],
    ),
    last_event_id: { type: 'integer', minimum: 0, maximum: 9_000_000_000_000_000 },
    ready_queue: boundedArray(unitIdSchema(), 500),
    running: boundedArray(unitIdSchema(), 500),
    blocked: boundedArray(unitIdSchema(), 500),
    completed: boundedArray(unitIdSchema(), 500),
    units: {
      type: 'object',
      additionalProperties: stateUnitSchema,
      propertyNames: unitIdSchema(),
      maxProperties: 2_000,
    },
    operator_questions: boundedArray(boundedString(500), 0),
    next_actions: boundedArray(boundedString(500), 80),
    work_items: {
      type: 'object',
      additionalProperties: workItemSchema,
      propertyNames: unitIdSchema(),
      maxProperties: 2_000,
    },
    audit_review_queue: boundedArray(unitIdSchema(), 500),
    validation_ready_queue: boundedArray(unitIdSchema(), 500),
    scope_exceptions: boundedArray(scopeExceptionSchema, 500),
    protected_path_exceptions: boundedArray(protectedPathExceptionSchema, 500),
    closure_gate: closureGateSchema,
  },
  required: [
    'schema_version',
    'workstream',
    'updated_at',
    'status',
    'context_gate',
    'last_event_id',
    'ready_queue',
    'running',
    'blocked',
    'completed',
    'units',
    'operator_questions',
    'next_actions',
  ],
} as const satisfies JsonMap;

export const AUTOPILOT_RECEIPT_JSON_SCHEMA = {
  $id: `${AUTOPILOT_SCHEMA_ID_BASE}/receipt.v1.json`,
  type: 'object',
  additionalProperties: false,
  properties: {
    schema_version: { const: 'autopilot.receipt.v1' },
    tool_name: { const: 'autopilot_emit_status' },
    workstream: workstreamSchema(),
    unit_id: unitIdSchema(),
    role: enumSchema(AUTOPILOT_ROLE_VALUES),
    attempt: { type: 'integer', minimum: 1, maximum: 999 },
    emitted_at: isoTimestampSchema(),
    status_output: absolutePathSchema(),
    status_sha256: sha256Schema(),
    schema_sha256: sha256Schema(),
    tool_call_id: opaqueToolCallIdJsonSchema(),
    provider_identity: noExtraMap(
      {
        provider_id: boundedString(120),
        requested_model_id: boundedString(120),
        executed_model_id: boundedString(120),
        api: boundedString(120),
        thinking_level: boundedString(40),
      },
      ['provider_id', 'requested_model_id', 'executed_model_id', 'api', 'thinking_level'],
    ),
    expected_identity_hash: sha256Schema(),
  },
  required: [
    'schema_version',
    'tool_name',
    'workstream',
    'unit_id',
    'role',
    'attempt',
    'emitted_at',
    'status_output',
    'status_sha256',
    'schema_sha256',
    'tool_call_id',
    'provider_identity',
    'expected_identity_hash',
  ],
} as const satisfies JsonMap;

export const AUTOPILOT_HANDOFF_JSON_SCHEMA = {
  $id: `${AUTOPILOT_SCHEMA_ID_BASE}/handoff.v1.json`,
  type: 'object',
  additionalProperties: false,
  properties: {
    schema_version: { const: 'autopilot.handoff.v1' },
    workstream: workstreamSchema(),
    written_at: isoTimestampSchema(),
    reason: enumSchema(AUTOPILOT_HANDOFF_REASON_VALUES),
    mission_ref: relativePathSchema(),
    master_plan_ref: relativePathSchema(),
    decision_tail_ref: { anyOf: [relativePathSchema(), { type: 'null' }] },
    latest_decision_id: { type: 'integer', minimum: 0, maximum: 9_000_000_000_000_000 },
    state_ref: relativePathSchema(),
    event_tail_ref: { anyOf: [relativePathSchema(), { type: 'null' }] },
    status_refs: boundedArray(relativePathSchema(), 500),
    audit_refs: boundedArray(relativePathSchema(), 500),
    summary: boundedString(1000),
    open_blockers: boundedArray(boundedString(500), 80),
    next_actions: boundedArray(boundedString(500), 80),
  },
  required: [
    'schema_version',
    'workstream',
    'written_at',
    'reason',
    'mission_ref',
    'master_plan_ref',
    'decision_tail_ref',
    'latest_decision_id',
    'state_ref',
    'event_tail_ref',
    'status_refs',
    'audit_refs',
    'summary',
    'open_blockers',
    'next_actions',
  ],
} as const satisfies JsonMap;

const masterPlanLaneSchema = noExtraMap(
  {
    lane_id: unitIdSchema(),
    summary: boundedString(360),
    unit_ids: boundedArray(unitIdSchema(), 500),
  },
  ['lane_id', 'summary', 'unit_ids'],
);

const masterPlanUnitSchema = noExtraMap(
  {
    unit_id: unitIdSchema(),
    role: enumSchema(AUTOPILOT_ROLE_VALUES),
    state: enumSchema(AUTOPILOT_UNIT_STATE_VALUES),
    dependencies: boundedArray(unitIdSchema(), 200),
    summary: boundedString(360),
  },
  ['unit_id', 'role', 'state', 'dependencies', 'summary'],
);

const ownershipMatrixSchema = noExtraMap(
  {
    owned_paths: boundedArray(relativePathSchema(), 500),
    read_only_paths: boundedArray(relativePathSchema(), 500),
    untouchable_paths: boundedArray(relativePathSchema(), 500),
    held_paths: boundedArray(relativePathSchema(), 500),
  },
  ['owned_paths', 'read_only_paths', 'untouchable_paths', 'held_paths'],
);

export const AUTOPILOT_MASTER_PLAN_JSON_SCHEMA = {
  $id: `${AUTOPILOT_SCHEMA_ID_BASE}/master-plan.v1.json`,
  type: 'object',
  additionalProperties: false,
  properties: {
    schema_version: { const: 'autopilot.master_plan.v1' },
    workstream: workstreamSchema(),
    mission_ref: relativePathSchema(),
    goal_summary: boundedString(1000),
    non_goals: boundedArray(boundedString(500), 80),
    definition_of_done: boundedArray(boundedString(500), 80),
    risk_level: enumSchema(AUTOPILOT_RISK_LEVEL_VALUES),
    lanes: boundedArray(masterPlanLaneSchema, 500),
    units: {
      type: 'object',
      additionalProperties: masterPlanUnitSchema,
      propertyNames: unitIdSchema(),
      maxProperties: 2_000,
    },
    ownership_matrix: ownershipMatrixSchema,
    verification_matrix: AUTOPILOT_VERIFICATION_PLAN_JSON_SCHEMA,
    closure_criteria: boundedArray(boundedString(500), 120),
    current_focus: boundedString(500),
    last_decision_id: { type: 'integer', minimum: 0, maximum: 9_000_000_000_000_000 },
    last_event_id: { type: 'integer', minimum: 0, maximum: 9_000_000_000_000_000 },
    updated_at: isoTimestampSchema(),
  },
  required: [
    'schema_version',
    'workstream',
    'mission_ref',
    'goal_summary',
    'non_goals',
    'definition_of_done',
    'risk_level',
    'lanes',
    'units',
    'ownership_matrix',
    'verification_matrix',
    'closure_criteria',
    'current_focus',
    'last_decision_id',
    'last_event_id',
    'updated_at',
  ],
} as const satisfies JsonMap;

export const AUTOPILOT_DECISION_ROW_JSON_SCHEMA = {
  $id: `${AUTOPILOT_SCHEMA_ID_BASE}/decision-row.v1.json`,
  type: 'object',
  additionalProperties: false,
  properties: {
    schema_version: { const: 'autopilot.decision.v1' },
    id: { type: 'integer', minimum: 1, maximum: 9_000_000_000_000_000 },
    ts: isoTimestampSchema(),
    event: enumSchema(AUTOPILOT_DECISION_EVENT_VALUES),
    workstream: workstreamSchema(),
    summary: boundedString(500),
    decision: boundedString(1000),
    unit_id: unitIdSchema(),
    master_plan_ref: relativePathSchema(),
    evidence_refs: boundedArray(AUTOPILOT_EVIDENCE_REF_JSON_SCHEMA, 80),
  },
  required: ['schema_version', 'id', 'ts', 'event', 'workstream', 'summary', 'decision'],
} as const satisfies JsonMap;

export const AUTOPILOT_EXECUTION_AUDIT_JSON_SCHEMA = {
  $id: `${AUTOPILOT_SCHEMA_ID_BASE}/execution-audit.v1.json`,
  type: 'object',
  additionalProperties: false,
  properties: {
    schema_version: { const: 'autopilot.execution_audit.v1' },
    workstream: workstreamSchema(),
    unit_id: unitIdSchema(),
    role: enumSchema(AUTOPILOT_ROLE_VALUES),
    attempt: { type: 'integer', minimum: 1, maximum: 999 },
    audited_at: isoTimestampSchema(),
    cwd: absolutePathSchema(),
    git_head: { anyOf: [boundedString(80), { type: 'null' }] },
    baseline_head: { anyOf: [boundedString(80), { type: 'null' }] },
    post_run_head: { anyOf: [boundedString(80), { type: 'null' }] },
    head_change_kind: enumSchema(AUTOPILOT_HEAD_CHANGE_KIND_VALUES),
    committed_changed_paths: boundedArray(relativePathSchema(), 500),
    dirty_baseline: { anyOf: [{ type: 'boolean' }, { type: 'null' }] },
    dirty_baseline_paths: boundedArray(relativePathSchema(), 500),
    dirty_relevant_paths: boundedArray(relativePathSchema(), 500),
    actual_changed_paths: boundedArray(relativePathSchema(), 500),
    status_reported_changed_paths: boundedArray(relativePathSchema(), 500),
    omitted_status_changes: boundedArray(relativePathSchema(), 500),
    reported_but_not_actual_changes: boundedArray(relativePathSchema(), 500),
    outside_owned_paths: boundedArray(relativePathSchema(), 500),
    read_only_touched_paths: boundedArray(relativePathSchema(), 500),
    untouchable_touched_paths: boundedArray(relativePathSchema(), 500),
    path_counts: AUTOPILOT_EXECUTION_AUDIT_PATH_COUNTS_JSON_SCHEMA,
    truncated_path_sets: boundedArray(enumSchema(AUTOPILOT_EXECUTION_AUDIT_PATH_SET_VALUES), 9),
    declared_validation_commands: boundedArray(boundedString(800), 120),
    status_reported_commands: boundedArray(boundedString(800), 120),
    command_coverage_gaps: boundedArray(boundedString(800), 120),
    classification: enumSchema(AUTOPILOT_AUDIT_CLASSIFICATION_VALUES),
    evidence_refs: boundedArray(AUTOPILOT_EVIDENCE_REF_JSON_SCHEMA, 80),
    summary: boundedString(1000),
  },
  required: [
    'schema_version',
    'workstream',
    'unit_id',
    'role',
    'attempt',
    'audited_at',
    'cwd',
    'git_head',
    'dirty_baseline',
    'dirty_baseline_paths',
    'dirty_relevant_paths',
    'actual_changed_paths',
    'status_reported_changed_paths',
    'omitted_status_changes',
    'reported_but_not_actual_changes',
    'outside_owned_paths',
    'read_only_touched_paths',
    'untouchable_touched_paths',
    'path_counts',
    'truncated_path_sets',
    'declared_validation_commands',
    'status_reported_commands',
    'command_coverage_gaps',
    'classification',
    'evidence_refs',
    'summary',
  ],
} as const satisfies JsonMap;

export const AUTOPILOT_EXECUTION_COMMIT_JSON_SCHEMA = {
  $id: `${AUTOPILOT_SCHEMA_ID_BASE}/execution-commit.v1.json`,
  type: 'object',
  additionalProperties: false,
  properties: {
    schema_version: { const: 'autopilot.execution_commit.v1' },
    workstream: workstreamSchema(),
    workstream_run: boundedString(180),
    autopilot_id: boundedString(200),
    active_run_epoch: { type: 'integer', minimum: 1, maximum: 9_000_000_000_000_000 },
    unit_id: unitIdSchema(),
    role: enumSchema(['implement', 'fix']),
    attempt: { type: 'integer', minimum: 1, maximum: 999 },
    cwd: absolutePathSchema(),
    branch: boundedString(240),
    claimed_paths: boundedArray(relativePathSchema(), 500),
    edited_claimed_paths: boundedArray(relativePathSchema(), 500, 1),
    before_head: boundedString(80),
    after_head: boundedString(80),
    commit_sha: boundedString(80),
    commit_subject: boundedString(240),
    commit_origin: enumSchema(AUTOPILOT_EXECUTION_COMMIT_ORIGIN_VALUES),
    commit_shas: boundedArray(boundedString(80), 500, 1),
    status_ref: relativePathSchema(),
    receipt_ref: relativePathSchema(),
    audit_ref: relativePathSchema(),
    created_at: isoTimestampSchema(),
  },
  required: [
    'schema_version',
    'workstream',
    'workstream_run',
    'autopilot_id',
    'active_run_epoch',
    'unit_id',
    'role',
    'attempt',
    'cwd',
    'branch',
    'claimed_paths',
    'edited_claimed_paths',
    'before_head',
    'after_head',
    'commit_sha',
    'commit_subject',
    'status_ref',
    'receipt_ref',
    'audit_ref',
    'created_at',
  ],
} as const satisfies JsonMap;

export const AUTOPILOT_JSON_SCHEMAS = Object.freeze({
  unitSpec: AUTOPILOT_UNIT_SPEC_JSON_SCHEMA,
  statusEntry: AUTOPILOT_STATUS_ENTRY_JSON_SCHEMA,
  eventRow: AUTOPILOT_EVENT_ROW_JSON_SCHEMA,
  state: AUTOPILOT_STATE_JSON_SCHEMA,
  receipt: AUTOPILOT_RECEIPT_JSON_SCHEMA,
  handoff: AUTOPILOT_HANDOFF_JSON_SCHEMA,
  masterPlan: AUTOPILOT_MASTER_PLAN_JSON_SCHEMA,
  decisionRow: AUTOPILOT_DECISION_ROW_JSON_SCHEMA,
  executionAudit: AUTOPILOT_EXECUTION_AUDIT_JSON_SCHEMA,
  executionCommit: AUTOPILOT_EXECUTION_COMMIT_JSON_SCHEMA,
});
